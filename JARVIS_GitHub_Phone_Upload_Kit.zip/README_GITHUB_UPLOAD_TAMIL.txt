JARVIS Tamil AI — GitHub phone-only upload method

1) Create/open your GitHub repository: JarvisTamilAssistant
2) On the repository page, tap Add file > Upload files.
3) Upload this file: JARVIS_Tamil_AI_Starter_v2.zip
4) Commit changes.
5) Now tap Add file > Create new file.
6) Set the filename to exactly:
   .github/workflows/build-from-zip.yml
7) Open build-from-zip.yml supplied separately with this kit, copy all its text, paste it into GitHub's editor, and Commit changes.
8) Open Actions tab > Build JARVIS Tamil APK from ZIP > Run workflow (if needed).
9) Open the successful run and download artifact jarvis-tamil-debug-apk. Extract that artifact ZIP to get app-debug.apk.

Important:
- This workflow builds the source in the uploaded ZIP; it does not deploy the AI backend.
- Build success has not yet been verified in this environment.
- Do not upload API keys, passwords, or secret tokens.
